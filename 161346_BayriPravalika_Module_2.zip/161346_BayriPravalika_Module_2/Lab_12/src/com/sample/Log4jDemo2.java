package com.sample;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Log4jDemo2 {
	static Logger logger=Logger.getLogger(Log4jDemo2.class);
    

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
		for(int i=1 ; i<5; i++) {
			System.out.println("Counter = " + i);
			logger.debug("This is my debug message. Counter = " + i);
			logger.info("This is my info  msg");
			logger.debug("This is my debug message");
			logger.error("This is my error message");
			logger.warn("This is my warn message");
			logger.fatal("This is my fatal message");
	}

	}
}
