package com.cg.eis.bean;

 

public interface EmployeeService {

public abstract void CheckInsuranceScheme();

 


}