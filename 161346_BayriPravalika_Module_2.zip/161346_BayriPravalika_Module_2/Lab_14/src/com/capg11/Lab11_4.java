package com.capg11;

class Lab11_4_1 implements ILab11_4 {
	int age;
	String name;
	int id;

	public Lab11_4_1(int id, String name, int age) {
		super();
		this.age = age;
		this.name = name;
		this.id = id;
	}

	public Lab11_4_1 getLamdaImp11_11_4(int id, String name, int age) {
		return null;
	}
}

public class Lab11_4 {
	public static void main(String[] args) {
		ILab11_4 im = Lab11_4_1::new;
		im.getLamdaImp11_11_4(101, "pravalika", 22);
	}
}
