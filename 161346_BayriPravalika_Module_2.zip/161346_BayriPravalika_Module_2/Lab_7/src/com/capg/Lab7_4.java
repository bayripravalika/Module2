package com.capg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Lab7_4 {
	public static HashMap<Integer, Integer> getSquares(int a[]) {
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int n : a) {
			map.put(n, n * n);
		}
		return map;
	}

	public static void main(String args[]) {
		int e;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter no of elements");
		int n = s.nextInt();
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = s.nextInt();
		}
		HashMap<Integer, Integer> map = getSquares(a);
		Iterator<Integer> it = map.keySet().iterator();
		while (it.hasNext()) {
			Integer key = it.next();
			System.out.println(key + " :" + map.get(key));
		}
	}

}
